<?php
define( 'MODERN_WORDPRESS_DEV', TRUE );