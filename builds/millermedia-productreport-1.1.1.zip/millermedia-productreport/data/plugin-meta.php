<?php
return <<<'JSON'
{
    "vendor": "Miller Media",
    "author": "Max Strukov",
    "name": "Product Report",
    "namespace": "MillerMedia\\ProductReport",
    "slug": "millermedia-productreport",
    "version": "1.1.1"
}
JSON;
